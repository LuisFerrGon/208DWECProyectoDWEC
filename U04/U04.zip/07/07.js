function tagTC(texto){
    document.getElementsByTagName("p").textContent=texto;
}
function tagIH(texto){
    document.getElementsByTagName("p").innerHTML=texto;
}
function tagIT(texto){
    document.getElementsByTagName("p").innerText=texto;
}
function idTC(texto){
    document.getElementById("parrafo").textContent=texto;
}
function idIH(texto){
    document.getElementById("parrafo").innerHTML=texto;
}
function idIT(texto){
    document.getElementById("parrafo").innerText=texto;
}