function seleccion(eleccion){
    switch(eleccion){
        case 'A':
            alert("A");
            break;
        case 'B':
            alert("B");
            break;
        case 'C':
            alert("C");
            break;
        default:
            alert("Otro");
        //
    }
}