var respuesta=prompt("A B C");
if(respuesta=='A'){
    alert("A");
}else if(respuesta=='B'){
    alert("B");
}else if(respuesta=='C'){
    alert("C");
}else{
    alert("Otra");
}